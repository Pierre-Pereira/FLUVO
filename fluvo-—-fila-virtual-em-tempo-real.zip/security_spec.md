# Security Specification — Fila Virtual

## 1. Data Invariants
1. A Queue document must be created only by a verified Google-authenticated user whose `request.auth.uid == incoming().ownerId`.
2. Queues contain zero PII (no emails, phone numbers, or addresses).
3. Tickets can only exist under an open parent Queue (`isOpen == true`), and `ticket.ownerId` must match the parent Queue's `ownerId`.
4. Ticket creation is atomically bound to incrementing the parent Queue's `lastTicketNumber` and `lastTicketId` via `getAfter` and `existsAfter`.
5. Once a Ticket reaches a terminal state (`served`, `cancelled`, `no_show`), no further updates are permitted.
6. Only the verified Queue owner can call customers (`called`), complete service (`served`), or mark `no_show`.
7. Guests can only cancel their own `waiting` ticket by presenting the matching SHA-256 preimage (`cancelToken`) for `cancelTokenHash`, or as the authenticated `customerUid`.
8. `list` queries on `queues` are strictly restricted to `resource.data.ownerId == request.auth.uid`.
9. `list` queries on `tickets` allow only active (`waiting`, `called`) tickets for the specified `queueId` or full history for the verified `ownerId` without using `get()` inside `allow list`.

## 2. The "Dirty Dozen" Attack Payloads (Expected: PERMISSION_DENIED)
1. **Identity Spoofing on Queue Create**: `{ ownerId: "victim-uid", ... }` by attacker UID -> Denied (`ownerId != request.auth.uid`).
2. **Unverified Email Queue Create**: Authenticated token with `email_verified: false` -> Denied.
3. **Shadow Ghost Field on Queue Create**: Valid fields plus `isFeatured: true` -> Denied (`hasOnly` rejects unknown fields).
4. **Oversized ID Poisoning**: Creating `/queues/` + `"a".repeat(200)` -> Denied (`isValidId` max 128).
5. **Blanket Queue List**: `getDocs(collection(db, "queues"))` without owner filter -> Denied (`resource.data.ownerId == request.auth.uid`).
6. **Client Timestamp Spoofing**: Creating a queue with `createdAt: Timestamp.fromMillis(1000)` -> Denied (`createdAt == request.time`).
7. **Orphan Ticket Creation**: Creating a ticket under a nonexistent `queueId` -> Denied (`exists()` fails).
8. **Closed Queue Injection**: Creating a ticket when parent queue has `isOpen: false` -> Denied.
9. **Ticket Number Jumping / Counter Desync**: Creating ticket with `ticketNumber: 999` without atomic `lastTicketNumber` increment -> Denied (`getAfter` mismatch).
10. **Guest Calling Themselves**: Updating own ticket `status` from `'waiting'` to `'called'` -> Denied (only owner can transition to `'called'`).
11. **Terminal State Resurrection**: Updating a `'served'` ticket back to `'waiting'` -> Denied (terminal state lock).
12. **Unauthorized Guest Cancellation**: Cancelling another customer's ticket with wrong `cancelToken` -> Denied (`hashing.sha256` mismatch).
