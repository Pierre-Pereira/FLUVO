import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import express, { type NextFunction, type Request, type Response } from 'express';

const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_PATH = path.join(DATA_DIR, 'vezcerta.db');
const PEPPER_PATH = path.join(DATA_DIR, '.db_pepper');

fs.mkdirSync(DATA_DIR, { recursive: true, mode: 0o700 });
try {
  fs.chmodSync(DATA_DIR, 0o700);
} catch {}

function loadOrCreatePepper(): Buffer {
  const envPepper = process.env.VEZCERTA_DB_PEPPER;
  if (envPepper && envPepper.length >= 32) {
    return crypto.createHash('sha256').update(envPepper, 'utf8').digest();
  }
  try {
    if (fs.existsSync(PEPPER_PATH)) {
      const hex = fs.readFileSync(PEPPER_PATH, 'utf8').trim();
      if (/^[a-f0-9]{64}$/i.test(hex)) {
        try { fs.chmodSync(PEPPER_PATH, 0o600); } catch {}
        return Buffer.from(hex, 'hex');
      }
    }
  } catch {}
  const fresh = crypto.randomBytes(32);
  fs.writeFileSync(PEPPER_PATH, fresh.toString('hex'), { mode: 0o600 });
  try { fs.chmodSync(PEPPER_PATH, 0o600); } catch {}
  return fresh;
}

const DB_PEPPER = loadOrCreatePepper();

const db = new DatabaseSync(DB_PATH);
db.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA synchronous = FULL;
  PRAGMA foreign_keys = ON;
  PRAGMA busy_timeout = 5000;
  PRAGMA trusted_schema = OFF;
  PRAGMA secure_delete = ON;

  CREATE TABLE IF NOT EXISTS queues (
    id TEXT PRIMARY KEY CHECK (length(id) BETWEEN 1 AND 128),
    admin_token_hash TEXT NOT NULL CHECK (length(admin_token_hash) BETWEEN 32 AND 256),
    establishment_name TEXT NOT NULL CHECK (length(establishment_name) BETWEEN 1 AND 80),
    queue_name TEXT NOT NULL CHECK (length(queue_name) BETWEEN 1 AND 80),
    prefix TEXT NOT NULL CHECK (length(prefix) BETWEEN 1 AND 4),
    estimated_minutes_per_person INTEGER NOT NULL DEFAULT 5 CHECK (estimated_minutes_per_person BETWEEN 1 AND 240),
    notify_before_count INTEGER NOT NULL DEFAULT 2 CHECK (notify_before_count BETWEEN 0 AND 20),
    is_open INTEGER NOT NULL DEFAULT 1 CHECK (is_open IN (0, 1)),
    archived INTEGER NOT NULL DEFAULT 0 CHECK (archived IN (0, 1)),
    last_ticket_number INTEGER NOT NULL DEFAULT 0 CHECK (last_ticket_number BETWEEN 0 AND 1000000),
    current_ticket_number INTEGER NOT NULL DEFAULT 0 CHECK (current_ticket_number BETWEEN 0 AND 1000000),
    current_ticket_code TEXT NOT NULL DEFAULT '' CHECK (length(current_ticket_code) <= 16),
    current_customer_name TEXT NOT NULL DEFAULT '' CHECK (length(current_customer_name) <= 40),
    created_at INTEGER NOT NULL CHECK (created_at > 0),
    updated_at INTEGER NOT NULL CHECK (updated_at >= created_at)
  );

  CREATE TABLE IF NOT EXISTS tickets (
    id TEXT PRIMARY KEY CHECK (length(id) BETWEEN 1 AND 128),
    queue_id TEXT NOT NULL REFERENCES queues(id) ON DELETE CASCADE,
    ticket_number INTEGER NOT NULL CHECK (ticket_number BETWEEN 1 AND 1000000),
    ticket_code TEXT NOT NULL CHECK (length(ticket_code) BETWEEN 1 AND 16),
    display_name TEXT NOT NULL CHECK (length(display_name) BETWEEN 1 AND 40),
    party_size INTEGER NOT NULL DEFAULT 1 CHECK (party_size BETWEEN 1 AND 20),
    note TEXT NOT NULL DEFAULT '' CHECK (length(note) <= 80),
    status TEXT NOT NULL DEFAULT 'waiting' CHECK (status IN ('waiting', 'called', 'served', 'cancelled', 'no_show')),
    cancel_token_hash TEXT NOT NULL CHECK (length(cancel_token_hash) BETWEEN 32 AND 256),
    called_at INTEGER,
    created_at INTEGER NOT NULL CHECK (created_at > 0),
    updated_at INTEGER NOT NULL CHECK (updated_at >= created_at)
  );

  CREATE UNIQUE INDEX IF NOT EXISTS idx_tickets_queue_unique_num ON tickets(queue_id, ticket_number);
  CREATE INDEX IF NOT EXISTS idx_tickets_queue_status ON tickets(queue_id, status, ticket_number);

  CREATE TRIGGER IF NOT EXISTS trg_queues_guard_update
  BEFORE UPDATE ON queues
  FOR EACH ROW
  BEGIN
    SELECT CASE
      WHEN OLD.archived = 1 THEN RAISE(ABORT, 'Queue is permanently archived')
      WHEN NEW.id != OLD.id THEN RAISE(ABORT, 'Queue id is immutable')
      WHEN NEW.admin_token_hash != OLD.admin_token_hash THEN RAISE(ABORT, 'Admin token hash is immutable')
      WHEN NEW.created_at != OLD.created_at THEN RAISE(ABORT, 'Queue created_at is immutable')
      WHEN NEW.last_ticket_number < OLD.last_ticket_number THEN RAISE(ABORT, 'Ticket counter cannot decrease')
      WHEN NEW.is_open NOT IN (0, 1) OR NEW.archived NOT IN (0, 1) THEN RAISE(ABORT, 'Invalid boolean flag')
      WHEN length(trim(NEW.establishment_name)) < 1 OR length(NEW.establishment_name) > 80 THEN RAISE(ABORT, 'Invalid establishment_name')
      WHEN length(trim(NEW.queue_name)) < 1 OR length(NEW.queue_name) > 80 THEN RAISE(ABORT, 'Invalid queue_name')
      WHEN NEW.estimated_minutes_per_person < 1 OR NEW.estimated_minutes_per_person > 240 THEN RAISE(ABORT, 'Invalid estimated_minutes_per_person')
      WHEN NEW.notify_before_count < 0 OR NEW.notify_before_count > 20 THEN RAISE(ABORT, 'Invalid notify_before_count')
    END;
  END;

  CREATE TRIGGER IF NOT EXISTS trg_tickets_guard_update
  BEFORE UPDATE ON tickets
  FOR EACH ROW
  BEGIN
    SELECT CASE
      WHEN NEW.id != OLD.id OR NEW.queue_id != OLD.queue_id THEN RAISE(ABORT, 'Ticket identity is immutable')
      WHEN NEW.ticket_number != OLD.ticket_number OR NEW.ticket_code != OLD.ticket_code THEN RAISE(ABORT, 'Ticket number is immutable')
      WHEN NEW.cancel_token_hash != OLD.cancel_token_hash THEN RAISE(ABORT, 'Cancel token hash is immutable')
      WHEN NEW.created_at != OLD.created_at THEN RAISE(ABORT, 'Ticket created_at is immutable')
      WHEN OLD.status NOT IN ('waiting', 'called') THEN RAISE(ABORT, 'Closed ticket cannot transition')
      WHEN NEW.status NOT IN ('waiting', 'called', 'served', 'cancelled', 'no_show') THEN RAISE(ABORT, 'Invalid ticket status')
    END;
  END;
`);

// Integrity verification on boot and strict OS file permissions
const integrityRow = db.prepare('PRAGMA quick_check').get() as unknown as Record<string, string> | undefined;
const integrityOk = integrityRow && Object.values(integrityRow)[0] === 'ok';
if (!integrityOk) {
  throw new Error('SQLite database integrity check failed');
}

function lockDbFilePermissions(): void {
  for (const suffix of ['', '-wal', '-shm']) {
    const p = DB_PATH + suffix;
    try {
      if (fs.existsSync(p)) fs.chmodSync(p, 0o600);
    } catch {}
  }
}
lockDbFilePermissions();

interface QueueRow {
  id: string;
  admin_token_hash: string;
  establishment_name: string;
  queue_name: string;
  prefix: string;
  estimated_minutes_per_person: number;
  notify_before_count: number;
  is_open: number;
  archived: number;
  last_ticket_number: number;
  current_ticket_number: number;
  current_ticket_code: string;
  current_customer_name: string;
  created_at: number;
  updated_at: number;
}

interface TicketRow {
  id: string;
  queue_id: string;
  ticket_number: number;
  ticket_code: string;
  display_name: string;
  party_size: number;
  note: string;
  status: string;
  cancel_token_hash: string;
  called_at: number | null;
  created_at: number;
  updated_at: number;
}

interface SseClient {
  res: Response;
  scope: 'admin' | 'customer';
  ticketId: string | null;
  ip: string;
}

interface RateBucket {
  count: number;
  resetAt: number;
}

interface SseTicketEntry {
  queueId: string;
  expiresAt: number;
}

const MAX_ACTIVE_TICKETS_PER_QUEUE = 500;
const MAX_SSE_PER_QUEUE = 150;
const MAX_SSE_PER_IP = 15;

const sseClients = new Map<string, Set<SseClient>>();
const sseIpCounts = new Map<string, number>();
const sseTickets = new Map<string, SseTicketEntry>();
const rateBuckets = new Map<string, RateBucket>();
const authStrikes = new Map<string, RateBucket>();

setInterval(() => {
  const now = Date.now();
  for (const [k, v] of sseTickets.entries()) {
    if (v.expiresAt <= now) sseTickets.delete(k);
  }
  for (const [k, v] of rateBuckets.entries()) {
    if (v.resetAt <= now) rateBuckets.delete(k);
  }
  for (const [k, v] of authStrikes.entries()) {
    if (v.resetAt <= now) authStrikes.delete(k);
  }
}, 60_000).unref();

function getClientIp(req: Request): string {
  return (req.ip || req.socket.remoteAddress || 'unknown').slice(0, 64);
}

function checkRateLimit(bucketMap: Map<string, RateBucket>, key: string, max: number, windowMs: number): boolean {
  const now = Date.now();
  const current = bucketMap.get(key);
  if (!current || current.resetAt <= now) {
    if (bucketMap.size > 20_000) bucketMap.clear();
    bucketMap.set(key, { count: 1, resetAt: now + windowMs });
    return true;
  }
  if (current.count >= max) return false;
  current.count += 1;
  return true;
}

function isAuthLocked(ip: string, queueId: string): boolean {
  const entry = authStrikes.get(`${ip}:${queueId}`);
  if (!entry) return false;
  if (entry.resetAt <= Date.now()) {
    authStrikes.delete(`${ip}:${queueId}`);
    return false;
  }
  return entry.count >= 10;
}

function recordAuthFailure(ip: string, queueId: string): void {
  checkRateLimit(authStrikes, `${ip}:${queueId}`, 10, 15 * 60_000);
}

function clearAuthFailures(ip: string, queueId: string): void {
  authStrikes.delete(`${ip}:${queueId}`);
}

function isValidId(val: unknown): val is string {
  return typeof val === 'string' && /^[a-zA-Z0-9_-]{1,128}$/.test(val);
}

function sanitizeText(val: unknown, maxLen: number): string {
  return String(val ?? '')
    .replace(/[\u0000-\u001F\u007F]/g, ' ')
    .trim()
    .slice(0, maxLen);
}

function generateId(bytes = 12): string {
  return crypto.randomBytes(bytes).toString('base64url');
}

function generateSecret(): string {
  return crypto.randomBytes(32).toString('base64url');
}

function hashSecret(token: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const mac = crypto.createHmac('sha256', DB_PEPPER).update(`${salt}:${token}`, 'utf8').digest('hex');
  return `v2$${salt}$${mac}`;
}

function verifySecret(token: string, storedHash: string): boolean {
  if (!token || token.length < 32 || token.length > 128 || !storedHash) return false;
  if (storedHash.startsWith('v2$')) {
    const parts = storedHash.split('$');
    if (parts.length !== 3) return false;
    const [, salt, expectedHex] = parts;
    const mac = crypto.createHmac('sha256', DB_PEPPER).update(`${salt}:${token}`, 'utf8').digest('hex');
    const a = Buffer.from(mac, 'utf8');
    const b = Buffer.from(expectedHex, 'utf8');
    if (a.length !== b.length) return false;
    return crypto.timingSafeEqual(a, b);
  }
  // Legacy unsalted hex hash compatibility
  const legacyHex = crypto.createHash('sha256').update(token, 'utf8').digest('hex');
  const a = Buffer.from(legacyHex, 'utf8');
  const b = Buffer.from(storedHash, 'utf8');
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

function extractAdminToken(req: Request): string {
  const auth = req.header('authorization') || '';
  if (auth.toLowerCase().startsWith('bearer ')) {
    return auth.slice(7).trim();
  }
  return (req.header('x-admin-token') || '').trim();
}

function formatCode(prefix: string, num: number): string {
  return `${(prefix || 'A').trim().toUpperCase()}-${String(num).padStart(3, '0')}`;
}

function serializeQueue(row: QueueRow, scope: 'admin' | 'customer') {
  return {
    id: row.id,
    establishmentName: row.establishment_name,
    queueName: row.queue_name,
    prefix: row.prefix,
    estimatedMinutesPerPerson: row.estimated_minutes_per_person,
    notifyBeforeCount: row.notify_before_count,
    isOpen: Boolean(row.is_open),
    archived: Boolean(row.archived),
    lastTicketNumber: row.last_ticket_number,
    currentTicketNumber: row.current_ticket_number,
    currentTicketCode: row.current_ticket_code,
    currentCustomerName: scope === 'admin' ? row.current_customer_name : '',
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

function serializeTicket(row: TicketRow, includePrivateNote: boolean) {
  return {
    id: row.id,
    queueId: row.queue_id,
    ticketNumber: row.ticket_number,
    ticketCode: row.ticket_code,
    displayName: row.display_name,
    partySize: row.party_size,
    note: includePrivateNote ? row.note : '',
    status: row.status,
    calledAt: row.called_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

function withImmediateTx<T>(fn: () => T): T {
  db.exec('BEGIN IMMEDIATE');
  try {
    const out = fn();
    db.exec('COMMIT');
    return out;
  } catch (err) {
    try {
      db.exec('ROLLBACK');
    } catch {}
    throw err;
  }
}

const stmtGetQueue = db.prepare('SELECT * FROM queues WHERE id = ?');
const stmtGetAllTickets = db.prepare('SELECT * FROM tickets WHERE queue_id = ? ORDER BY ticket_number ASC');
const stmtGetActiveTickets = db.prepare(
  "SELECT * FROM tickets WHERE queue_id = ? AND status IN ('waiting', 'called') ORDER BY ticket_number ASC"
);
const stmtCountActiveTickets = db.prepare(
  "SELECT COUNT(*) AS cnt FROM tickets WHERE queue_id = ? AND status IN ('waiting', 'called')"
);
const stmtGetTicketById = db.prepare('SELECT * FROM tickets WHERE id = ? AND queue_id = ?');

function buildQueueSnapshot(queueId: string, scope: 'admin' | 'customer', ticketId: string | null) {
  const row = stmtGetQueue.get(queueId) as QueueRow | undefined;
  if (!row || row.archived) {
    return { notFound: true, queue: null, tickets: [], myTicket: null };
  }
  const queue = serializeQueue(row, scope);
  if (scope === 'admin') {
    const rows = stmtGetAllTickets.all(queueId) as unknown as TicketRow[];
    return { notFound: false, queue, tickets: rows.map((r) => serializeTicket(r, true)), myTicket: null };
  }
  const activeRows = stmtGetActiveTickets.all(queueId) as unknown as TicketRow[];
  // Data minimization for public customer view: hide other customers' private notes
  const tickets = activeRows.map((r) => serializeTicket(r, Boolean(ticketId && r.id === ticketId)));
  let myTicket = ticketId ? tickets.find((t) => t.id === ticketId) || null : null;
  if (ticketId && !myTicket) {
    const ownRow = stmtGetTicketById.get(ticketId, queueId) as TicketRow | undefined;
    if (ownRow) myTicket = serializeTicket(ownRow, true);
  }
  return { notFound: false, queue, tickets, myTicket };
}

function broadcastQueueUpdate(queueId: string, closeAfter = false): void {
  const clients = sseClients.get(queueId);
  if (!clients || clients.size === 0) return;

  for (const client of clients) {
    try {
      const payload = buildQueueSnapshot(queueId, client.scope, client.ticketId);
      client.res.write(`event: sync\ndata: ${JSON.stringify(payload)}\n\n`);
      if (closeAfter) {
        client.res.end();
      }
    } catch {
      clients.delete(client);
    }
  }
  if (closeAfter) sseClients.delete(queueId);
}

function requireAdminQueue(req: Request, res: Response): QueueRow | null {
  const { queueId } = req.params;
  if (!isValidId(queueId)) {
    res.status(400).json({ error: 'Código de fila inválido.' });
    return null;
  }
  const ip = getClientIp(req);
  if (isAuthLocked(ip, queueId)) {
    res.status(429).json({ error: 'Muitas tentativas inválidas. Aguarde alguns minutos e tente novamente.' });
    return null;
  }
  const row = stmtGetQueue.get(queueId) as QueueRow | undefined;
  if (!row || row.archived) {
    res.status(404).json({ error: 'Fila não encontrada ou já encerrada.' });
    return null;
  }
  const token = extractAdminToken(req);
  if (!verifySecret(token, row.admin_token_hash)) {
    recordAuthFailure(ip, queueId);
    res.status(403).json({ error: 'Chave de gerenciamento inválida ou ausente.' });
    return null;
  }
  clearAuthFailures(ip, queueId);
  return row;
}

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);

// Global Security Headers
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  if (req.path.startsWith('/api/')) {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
  }
  next();
});

// Global API rate limit & strict Content-Type on mutations
app.use('/api/', (req, res, next) => {
  const ip = getClientIp(req);
  if (!checkRateLimit(rateBuckets, `global:${ip}`, 240, 60_000)) {
    res.status(429).json({ error: 'Muitas solicitações seguidas. Aguarde um instante.' });
    return;
  }
  if ((req.method === 'POST' || req.method === 'PATCH') && !req.is('application/json')) {
    res.status(415).json({ error: 'Tipo de conteúdo inválido.' });
    return;
  }
  next();
});

app.use(express.json({ limit: '16kb', strict: true }));

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, database: 'sqlite-hardened' });
});

app.post('/api/queues', (req, res) => {
  const ip = getClientIp(req);
  if (!checkRateLimit(rateBuckets, `create_queue:${ip}`, 15, 15 * 60_000)) {
    res.status(429).json({ error: 'Limite temporário de criação de filas atingido. Tente novamente em alguns minutos.' });
    return;
  }

  const body = req.body && typeof req.body === 'object' ? req.body : {};
  const establishmentName = sanitizeText(body.establishmentName, 80);
  const queueName = sanitizeText(body.queueName, 80);
  if (!establishmentName || !queueName) {
    res.status(400).json({ error: 'Preencha o nome do estabelecimento e o nome da fila.' });
    return;
  }

  const rawPrefix = sanitizeText(body.prefix || 'A', 12).toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4);
  const prefix = rawPrefix || 'A';

  const parsedMin = Number(body.estimatedMinutesPerPerson);
  const estMin = Number.isFinite(parsedMin) ? Math.min(240, Math.max(1, Math.round(parsedMin))) : 5;

  const parsedNotify = Number(body.notifyBeforeCount);
  const notifyBefore = Number.isFinite(parsedNotify) ? Math.min(20, Math.max(0, Math.round(parsedNotify))) : 2;

  const id = generateId(12);
  const adminToken = generateSecret();
  const adminTokenHash = hashSecret(adminToken);
  const now = Date.now();

  db.prepare(`
    INSERT INTO queues (
      id, admin_token_hash, establishment_name, queue_name, prefix,
      estimated_minutes_per_person, notify_before_count,
      is_open, archived, last_ticket_number, current_ticket_number,
      current_ticket_code, current_customer_name, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, 1, 0, 0, 0, '', '', ?, ?)
  `).run(id, adminTokenHash, establishmentName, queueName, prefix, estMin, notifyBefore, now, now);

  lockDbFilePermissions();
  const created = stmtGetQueue.get(id) as unknown as QueueRow;
  res.status(201).json({ queue: serializeQueue(created, 'admin'), adminToken });
});

app.post('/api/queues/:queueId/stream-ticket', (req, res) => {
  const row = requireAdminQueue(req, res);
  if (!row) return;

  const sseTicket = generateSecret();
  sseTickets.set(sseTicket, { queueId: row.id, expiresAt: Date.now() + 30_000 });
  res.json({ sseTicket });
});

app.get('/api/queues/:queueId', (req, res) => {
  const { queueId } = req.params;
  if (!isValidId(queueId)) {
    res.status(400).json({ error: 'Código de fila inválido.' });
    return;
  }
  const ip = getClientIp(req);
  if (req.query.scope === 'admin' && isAuthLocked(ip, queueId)) {
    res.status(429).json({ error: 'Muitas tentativas inválidas. Aguarde alguns minutos.' });
    return;
  }
  const row = stmtGetQueue.get(queueId) as QueueRow | undefined;
  if (!row || row.archived) {
    res.status(404).json({ error: 'Fila não encontrada ou encerrada.' });
    return;
  }

  let isAdmin = false;
  if (req.query.scope === 'admin') {
    const token = extractAdminToken(req);
    isAdmin = verifySecret(token, row.admin_token_hash);
    if (!isAdmin) {
      recordAuthFailure(ip, queueId);
      res.status(403).json({ error: 'Chave de gerenciamento inválida.' });
      return;
    }
    clearAuthFailures(ip, queueId);
  }

  const ticketId = isValidId(req.query.ticketId) ? req.query.ticketId : null;
  const payload = buildQueueSnapshot(queueId, isAdmin ? 'admin' : 'customer', ticketId);
  res.json(payload);
});

app.get('/api/queues/:queueId/stream', (req, res) => {
  const { queueId } = req.params;
  if (!isValidId(queueId)) {
    res.status(400).end();
    return;
  }

  const ip = getClientIp(req);
  const currentIpCount = sseIpCounts.get(ip) || 0;
  const existingQueueSet = sseClients.get(queueId);
  if (currentIpCount >= MAX_SSE_PER_IP || (existingQueueSet && existingQueueSet.size >= MAX_SSE_PER_QUEUE)) {
    res.status(429).end();
    return;
  }

  let scope: 'admin' | 'customer' = 'customer';
  if (req.query.scope === 'admin') {
    const sseTicket = typeof req.query.sseTicket === 'string' ? req.query.sseTicket.trim() : '';
    const entry = sseTicket ? sseTickets.get(sseTicket) : undefined;
    if (entry && entry.queueId === queueId && entry.expiresAt > Date.now()) {
      sseTickets.delete(sseTicket);
      scope = 'admin';
    } else {
      res.status(403).end();
      return;
    }
  }
  const ticketId = isValidId(req.query.ticketId) ? req.query.ticketId : null;

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders?.();

  const client: SseClient = { res, scope, ticketId, ip };
  let set = sseClients.get(queueId);
  if (!set) {
    set = new Set();
    sseClients.set(queueId, set);
  }
  set.add(client);
  sseIpCounts.set(ip, currentIpCount + 1);

  const initial = buildQueueSnapshot(queueId, scope, ticketId);
  res.write(`event: sync\ndata: ${JSON.stringify(initial)}\n\n`);

  const ping = setInterval(() => {
    try {
      res.write(': ping\n\n');
    } catch {
      clearInterval(ping);
    }
  }, 25_000);

  req.on('close', () => {
    clearInterval(ping);
    const currentSet = sseClients.get(queueId);
    if (currentSet) {
      currentSet.delete(client);
      if (currentSet.size === 0) sseClients.delete(queueId);
    }
    const c = sseIpCounts.get(ip) || 0;
    if (c <= 1) sseIpCounts.delete(ip);
    else sseIpCounts.set(ip, c - 1);
  });
});

app.patch('/api/queues/:queueId', (req, res) => {
  const row = requireAdminQueue(req, res);
  if (!row) return;

  const body = req.body && typeof req.body === 'object' ? req.body : {};
  let establishmentName = row.establishment_name;
  let queueName = row.queue_name;
  let estMin = row.estimated_minutes_per_person;
  let notifyBefore = row.notify_before_count;
  let isOpen = row.is_open;

  if (body.establishmentName !== undefined) {
    const clean = sanitizeText(body.establishmentName, 80);
    if (!clean) {
      res.status(400).json({ error: 'O nome do estabelecimento não pode ficar em branco.' });
      return;
    }
    establishmentName = clean;
  }
  if (body.queueName !== undefined) {
    const clean = sanitizeText(body.queueName, 80);
    if (!clean) {
      res.status(400).json({ error: 'O nome da fila não pode ficar em branco.' });
      return;
    }
    queueName = clean;
  }
  if (body.estimatedMinutesPerPerson !== undefined) {
    const parsed = Number(body.estimatedMinutesPerPerson);
    estMin = Number.isFinite(parsed) ? Math.min(240, Math.max(1, Math.round(parsed))) : row.estimated_minutes_per_person;
  }
  if (body.notifyBeforeCount !== undefined) {
    const parsed = Number(body.notifyBeforeCount);
    notifyBefore = Number.isFinite(parsed) ? Math.min(20, Math.max(0, Math.round(parsed))) : row.notify_before_count;
  }
  if (typeof body.isOpen === 'boolean') {
    isOpen = body.isOpen ? 1 : 0;
  }

  const now = Date.now();
  db.prepare(`
    UPDATE queues
    SET establishment_name = ?, queue_name = ?, estimated_minutes_per_person = ?,
        notify_before_count = ?, is_open = ?, updated_at = ?
    WHERE id = ?
  `).run(establishmentName, queueName, estMin, notifyBefore, isOpen, now, row.id);

  const updated = stmtGetQueue.get(row.id) as unknown as QueueRow;
  broadcastQueueUpdate(row.id);
  res.json({ queue: serializeQueue(updated, 'admin') });
});

app.post('/api/queues/:queueId/archive', (req, res) => {
  const row = requireAdminQueue(req, res);
  if (!row) return;

  const now = Date.now();
  withImmediateTx(() => {
    db.prepare('UPDATE tickets SET note = \'\', updated_at = ? WHERE queue_id = ?').run(now, row.id);
    db.prepare('UPDATE queues SET archived = 1, is_open = 0, current_customer_name = \'\', updated_at = ? WHERE id = ?').run(now, row.id);
  });
  broadcastQueueUpdate(row.id, true);
  res.json({ ok: true });
});

app.post('/api/queues/:queueId/tickets', (req, res) => {
  const { queueId } = req.params;
  if (!isValidId(queueId)) {
    res.status(400).json({ error: 'Código de fila inválido.' });
    return;
  }

  const ip = getClientIp(req);
  const adminHeader = extractAdminToken(req);
  const qCheck = stmtGetQueue.get(queueId) as QueueRow | undefined;
  const isAdminWalkIn = Boolean(qCheck && !qCheck.archived && adminHeader && verifySecret(adminHeader, qCheck.admin_token_hash));

  if (!isAdminWalkIn && !checkRateLimit(rateBuckets, `join:${ip}:${queueId}`, 15, 5 * 60_000)) {
    res.status(429).json({ error: 'Muitas entradas recentes deste dispositivo. Aguarde alguns minutos.' });
    return;
  }
  if (isAdminWalkIn && !checkRateLimit(rateBuckets, `walkin:${ip}:${queueId}`, 120, 5 * 60_000)) {
    res.status(429).json({ error: 'Muitas adições em sequência. Aguarde um instante.' });
    return;
  }

  const body = req.body && typeof req.body === 'object' ? req.body : {};
  const displayName = sanitizeText(body.displayName, 40);
  if (!displayName) {
    res.status(400).json({ error: 'Informe o nome para gerar a senha.' });
    return;
  }
  const parsedParty = Number(body.partySize);
  const partySize = Number.isFinite(parsedParty) ? Math.min(20, Math.max(1, Math.round(parsedParty))) : 1;
  const note = sanitizeText(body.note, 80);

  try {
    const result = withImmediateTx(() => {
      const q = stmtGetQueue.get(queueId) as QueueRow | undefined;
      if (!q || q.archived) {
        throw Object.assign(new Error('Fila não encontrada.'), { statusCode: 404 });
      }
      if (!q.is_open) {
        throw Object.assign(new Error('Esta fila está pausada no momento.'), { statusCode: 409 });
      }
      const activeCountRow = stmtCountActiveTickets.get(queueId) as unknown as { cnt: number };
      if ((activeCountRow?.cnt || 0) >= MAX_ACTIVE_TICKETS_PER_QUEUE) {
        throw Object.assign(new Error('Esta fila atingiu o limite máximo de senhas ativas.'), { statusCode: 429 });
      }
      if (q.last_ticket_number >= 1_000_000) {
        throw Object.assign(new Error('Limite de senhas desta fila atingido. Crie uma nova fila.'), { statusCode: 409 });
      }

      const nextNum = q.last_ticket_number + 1;
      const ticketCode = formatCode(q.prefix, nextNum);
      const ticketId = generateId(12);
      const cancelToken = generateSecret();
      const cancelTokenHash = hashSecret(cancelToken);
      const now = Date.now();

      db.prepare('UPDATE queues SET last_ticket_number = ?, updated_at = ? WHERE id = ?').run(nextNum, now, queueId);
      db.prepare(`
        INSERT INTO tickets (
          id, queue_id, ticket_number, ticket_code, display_name,
          party_size, note, status, cancel_token_hash, called_at, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'waiting', ?, NULL, ?, ?)
      `).run(ticketId, queueId, nextNum, ticketCode, displayName, partySize, note, cancelTokenHash, now, now);

      const ticketRow = stmtGetTicketById.get(ticketId, queueId) as unknown as TicketRow;
      return { ticket: serializeTicket(ticketRow, true), cancelToken };
    });

    broadcastQueueUpdate(queueId);
    res.status(201).json(result);
  } catch (err: unknown) {
    const status = (err as { statusCode?: number }).statusCode || 500;
    const message = status < 500 && err instanceof Error ? err.message : 'Erro ao gerar senha.';
    res.status(status).json({ error: message });
  }
});

app.post('/api/queues/:queueId/tickets/:ticketId/call', (req, res) => {
  const row = requireAdminQueue(req, res);
  if (!row) return;
  const { ticketId } = req.params;
  if (!isValidId(ticketId)) {
    res.status(400).json({ error: 'Senha inválida.' });
    return;
  }

  try {
    withImmediateTx(() => {
      const target = stmtGetTicketById.get(ticketId, row.id) as TicketRow | undefined;
      if (!target) {
        throw Object.assign(new Error('Senha não encontrada nesta fila.'), { statusCode: 404 });
      }
      if (target.status !== 'waiting') {
        throw Object.assign(new Error('Apenas senhas aguardando podem ser chamadas.'), { statusCode: 409 });
      }
      const now = Date.now();
      db.prepare(
        "UPDATE tickets SET status = 'served', updated_at = ? WHERE queue_id = ? AND status = 'called' AND id != ?"
      ).run(now, row.id, target.id);

      db.prepare(
        "UPDATE tickets SET status = 'called', called_at = ?, updated_at = ? WHERE id = ? AND queue_id = ?"
      ).run(now, now, target.id, row.id);

      db.prepare(`
        UPDATE queues
        SET current_ticket_number = ?, current_ticket_code = ?, current_customer_name = ?, updated_at = ?
        WHERE id = ?
      `).run(target.ticket_number, target.ticket_code, target.display_name, now, row.id);
    });

    broadcastQueueUpdate(row.id);
    res.json({ ok: true });
  } catch (err: unknown) {
    const status = (err as { statusCode?: number }).statusCode || 500;
    const message = status < 500 && err instanceof Error ? err.message : 'Erro ao chamar cliente.';
    res.status(status).json({ error: message });
  }
});

app.post('/api/queues/:queueId/tickets/:ticketId/recall', (req, res) => {
  const row = requireAdminQueue(req, res);
  if (!row) return;
  const { ticketId } = req.params;
  if (!isValidId(ticketId)) {
    res.status(400).json({ error: 'Senha inválida.' });
    return;
  }

  const target = stmtGetTicketById.get(ticketId, row.id) as TicketRow | undefined;
  if (!target || target.status !== 'called') {
    res.status(409).json({ error: 'Esta senha não está sendo chamada no momento.' });
    return;
  }
  const now = Date.now();
  db.prepare('UPDATE tickets SET called_at = ?, updated_at = ? WHERE id = ? AND queue_id = ?').run(now, now, target.id, row.id);
  broadcastQueueUpdate(row.id);
  res.json({ ok: true });
});

app.post('/api/queues/:queueId/tickets/:ticketId/status', (req, res) => {
  const row = requireAdminQueue(req, res);
  if (!row) return;
  const { ticketId } = req.params;
  if (!isValidId(ticketId)) {
    res.status(400).json({ error: 'Senha inválida.' });
    return;
  }
  const nextStatus = req.body && typeof req.body.status === 'string' ? req.body.status : '';
  if (!['served', 'no_show', 'cancelled'].includes(nextStatus)) {
    res.status(400).json({ error: 'Status inválido.' });
    return;
  }

  try {
    withImmediateTx(() => {
      const target = stmtGetTicketById.get(ticketId, row.id) as TicketRow | undefined;
      if (!target) {
        throw Object.assign(new Error('Senha não encontrada.'), { statusCode: 404 });
      }
      if (!['waiting', 'called'].includes(target.status)) {
        throw Object.assign(new Error('Esta senha já foi encerrada.'), { statusCode: 409 });
      }
      const now = Date.now();
      db.prepare('UPDATE tickets SET status = ?, updated_at = ? WHERE id = ? AND queue_id = ?').run(nextStatus, now, target.id, row.id);
      if (target.status === 'called') {
        db.prepare(
          "UPDATE queues SET current_ticket_number = 0, current_ticket_code = '', current_customer_name = '', updated_at = ? WHERE id = ?"
        ).run(now, row.id);
      }
    });

    broadcastQueueUpdate(row.id);
    res.json({ ok: true });
  } catch (err: unknown) {
    const status = (err as { statusCode?: number }).statusCode || 500;
    const message = status < 500 && err instanceof Error ? err.message : 'Erro ao atualizar senha.';
    res.status(status).json({ error: message });
  }
});

app.post('/api/queues/:queueId/tickets/:ticketId/cancel', (req, res) => {
  const { queueId, ticketId } = req.params;
  if (!isValidId(queueId) || !isValidId(ticketId)) {
    res.status(400).json({ error: 'Parâmetros inválidos.' });
    return;
  }
  const ip = getClientIp(req);
  if (isAuthLocked(ip, `cancel:${ticketId}`)) {
    res.status(429).json({ error: 'Muitas tentativas inválidas. Aguarde alguns minutos.' });
    return;
  }
  const cancelToken = req.body && typeof req.body.cancelToken === 'string' ? req.body.cancelToken.trim() : '';

  try {
    withImmediateTx(() => {
      const q = stmtGetQueue.get(queueId) as QueueRow | undefined;
      if (!q || q.archived) {
        throw Object.assign(new Error('Fila não encontrada.'), { statusCode: 404 });
      }
      const target = stmtGetTicketById.get(ticketId, queueId) as TicketRow | undefined;
      if (!target) {
        throw Object.assign(new Error('Senha não encontrada.'), { statusCode: 404 });
      }
      if (!verifySecret(cancelToken, target.cancel_token_hash)) {
        recordAuthFailure(ip, `cancel:${ticketId}`);
        throw Object.assign(new Error('Token de cancelamento inválido.'), { statusCode: 403 });
      }
      clearAuthFailures(ip, `cancel:${ticketId}`);
      if (target.status !== 'waiting') {
        throw Object.assign(new Error('A senha não está mais aguardando na fila.'), { statusCode: 409 });
      }
      const now = Date.now();
      db.prepare("UPDATE tickets SET status = 'cancelled', updated_at = ? WHERE id = ? AND queue_id = ?").run(now, ticketId, queueId);
    });

    broadcastQueueUpdate(queueId);
    res.json({ ok: true });
  } catch (err: unknown) {
    const status = (err as { statusCode?: number }).statusCode || 500;
    const message = status < 500 && err instanceof Error ? err.message : 'Erro ao sair da fila.';
    res.status(status).json({ error: message });
  }
});

app.use((err: unknown, req: Request, res: Response, next: NextFunction) => {
  if (req.path.startsWith('/api/')) {
    if (err instanceof SyntaxError) {
      res.status(400).json({ error: 'JSON inválido na solicitação.' });
      return;
    }
    console.error('API Error:', err instanceof Error ? err.message : 'unknown');
    res.status(500).json({ error: 'Erro interno no servidor.' });
    return;
  }
  next(err);
});

async function start() {
  const server = http.createServer(app);

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: { server }
      },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`VezCerta server listening on http://0.0.0.0:${PORT}`);
  });

  const shutdown = () => {
    for (const clients of sseClients.values()) {
      for (const client of clients) {
        try { client.res.end(); } catch {}
      }
    }
    sseClients.clear();
    server.close(() => {
      try { db.close(); } catch {}
      process.exit(0);
    });
    setTimeout(() => {
      try { db.close(); } catch {}
      process.exit(0);
    }, 3000).unref();
  };

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

start().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
